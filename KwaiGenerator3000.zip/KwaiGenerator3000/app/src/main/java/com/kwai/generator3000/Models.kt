package com.kwai.generator3000

/** Las personalidades que puede imitar el generador. */
enum class Personality(val label: String, val emoji: String, val blurb: String) {
    POLITES("Polites.exe", "🤪", "Gritos, errores y cambios de tema"),
    NEKO("Neko Kawaii", "🐱", "Nya, miau y ternura extrema"),
    SENPAI("Onichan / Senpai", "🌸", "Tartamudeos y vergüenza fingida"),
    GLITCH("Glitch Humano", "👾", "Palabras mezcladas y errores"),
    RANDOM_GOD("Dios del Random", "🎲", "Humor absurdo e impredecible"),
    MIX("Mezcla Total", "🌀", "Todas las personalidades juntas")
}

/** Nivel de caos: cambia las probabilidades de gritos, cambios de tema y glitches. */
enum class Chaos(val label: String) {
    CALM("Tranquilo"),
    CHAOTIC("Caótico"),
    UNHINGED("Desquiciado")
}

/** Longitud aproximada del mensaje. */
enum class Length(val label: String) {
    SHORT("Corto"),
    MEDIUM("Mediano"),
    LONG("Largo")
}

/** Cantidad de emojis que se añaden al mensaje. */
enum class EmojiAmount(val label: String) {
    FEW("Pocos"),
    NORMAL("Normal"),
    MANY("Muchos")
}

/** Tema sobre el que habla el mensaje. */
enum class Topic(val label: String) {
    NONE("Sin tema"),
    ANIME("Anime"),
    FOOD("Comida"),
    ANIMALS("Animales"),
    SHAME("Vergüenza"),
    SCREAMS("Gritos"),
    RANDOM("Frases random")
}

/** Estilo de escritura aplicado al texto final. */
enum class WritingStyle(val label: String) {
    NORMAL("Normal"),
    CAPS("MAYÚSCULAS"),
    STUTTER("Tartamudeo"),
    TYPOS("Errores"),
    MIX("Mezcla")
}

/** Pestañas de la barra inferior. */
enum class Tab { GENERATE, FAVORITES, HISTORY }

/** Todos los ajustes que elige la persona antes de generar. */
data class GenSettings(
    val personality: Personality = Personality.MIX,
    val chaos: Chaos = Chaos.CHAOTIC,
    val length: Length = Length.MEDIUM,
    val emoji: EmojiAmount = EmojiAmount.NORMAL,
    val topic: Topic = Topic.NONE,
    val style: WritingStyle = WritingStyle.NORMAL
)

/** Mensaje guardado (historial o favoritos). [personality] guarda el nombre del enum. */
data class SavedMessage(
    val id: Long,
    val text: String,
    val personality: String,
    val createdAt: Long
) {
    /** Etiqueta bonita con la personalidad usada, por ejemplo "🐱 Neko Kawaii". */
    fun badge(): String =
        Personality.entries.firstOrNull { it.name == personality }
            ?.let { "${it.emoji} ${it.label}" }
            ?: "✨ Kwai"
}
