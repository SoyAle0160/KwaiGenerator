package com.kwai.generator3000

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

// ═══════════════════════════ RAÍZ ═══════════════════════════

/** Pantalla raíz: cabecera, contenido de la pestaña activa y barra inferior. */
@Composable
fun KwaiApp(vm: MainViewModel = viewModel()) {
    KwaiTheme {
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(KwaiLavender, KwaiPinkSoft, KwaiSkySoft)))
        ) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                AppHeader(vm.totalGenerated)
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (vm.tab) {
                        Tab.GENERATE -> GenerateScreen(vm)
                        Tab.FAVORITES -> FavoritesScreen(vm)
                        Tab.HISTORY -> HistoryScreen(vm)
                    }
                }
                BottomBar(vm.tab, vm.favorites.size) { vm.tab = it }
            }
        }
    }
}

@Composable
private fun AppHeader(total: Int) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                "Kwai Generator 3000",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = KwaiPurpleDark
            )
            Text("el laboratorio del caos kawaii ✨", fontSize = 12.sp, color = KwaiPurple)
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.75f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text("💥 $total", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KwaiPurpleDark)
        }
    }
}

// ═══════════════════════════ PESTAÑA: GENERAR ═══════════════════════════

@Composable
private fun GenerateScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val current = vm.current
    val isFav = current != null && vm.isFavorite(current.text)

    // Tanto "GENERAR CAOS" como "GENERAR OTRO" generan un mensaje nuevo con los mismos ajustes.
    val generate: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        vm.generate()
    }

    Column(Modifier.fillMaxSize()) {
        // Zona desplazable: personalidades, ajustes y mensaje.
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            PersonalitySelector(vm.settings.personality) { p ->
                vm.updateSettings { it.copy(personality = p) }
            }
            SettingsCard(
                s = vm.settings,
                expanded = vm.settingsExpanded,
                onToggle = { vm.settingsExpanded = !vm.settingsExpanded },
                onChange = { change -> vm.updateSettings(change) }
            )
            MessageCard(current, isFav)
            Spacer(Modifier.height(4.dp))
        }

        // Zona fija abajo (alcance del pulgar): botones principales.
        ActionArea(
            hasMessage = current != null,
            isFav = isFav,
            onGenerate = generate,
            onCopy = { current?.let { copyToClipboard(context, it.text) } },
            onAnother = generate,
            onFav = { current?.let { vm.toggleFavorite(it) } },
            onShare = { current?.let { shareText(context, it.text) } }
        )
    }
}

@Composable
private fun PersonalitySelector(selected: Personality, onSelect: (Personality) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Personality.entries.forEach { p ->
            val isSelected = p == selected
            val cardBrush = if (isSelected) {
                Brush.linearGradient(listOf(KwaiPurple, KwaiPink))
            } else {
                Brush.linearGradient(listOf(Color.White, Color.White))
            }
            Column(
                Modifier
                    .width(118.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(cardBrush)
                    .clickable { onSelect(p) }
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(p.emoji, fontSize = 28.sp)
                Text(
                    p.label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = if (isSelected) Color.White else KwaiInk
                )
                Text(
                    p.blurb,
                    fontSize = 10.sp,
                    lineHeight = 12.sp,
                    textAlign = TextAlign.Center,
                    color = if (isSelected) Color.White.copy(alpha = 0.9f) else KwaiInk.copy(alpha = 0.6f)
                )
            }
        }
    }
}

/** Tarjeta plegable con los 5 controles de personalización. */
@Composable
private fun SettingsCard(
    s: GenSettings,
    expanded: Boolean,
    onToggle: () -> Unit,
    onChange: ((GenSettings) -> GenSettings) -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.85f))
            .animateContentSize()
            .padding(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "⚙️ Ajustes del caos",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = KwaiPurpleDark
                )
                if (!expanded) {
                    Text(
                        "${s.chaos.label} · ${s.length.label} · ${s.emoji.label} emojis · ${s.topic.label} · ${s.style.label}",
                        fontSize = 12.sp,
                        color = KwaiInk.copy(alpha = 0.6f)
                    )
                }
            }
            Text(if (expanded) "▲" else "▼", fontSize = 16.sp, color = KwaiPurple)
        }
        if (expanded) {
            OptionRow("🔥 Nivel de caos", Chaos.entries, s.chaos, { it.label }) { v ->
                onChange { it.copy(chaos = v) }
            }
            OptionRow("📏 Longitud", Length.entries, s.length, { it.label }) { v ->
                onChange { it.copy(length = v) }
            }
            OptionRow("😀 Cantidad de emojis", EmojiAmount.entries, s.emoji, { it.label }) { v ->
                onChange { it.copy(emoji = v) }
            }
            OptionRow("🏷️ Tema", Topic.entries, s.topic, { it.label }) { v ->
                onChange { it.copy(topic = v) }
            }
            OptionRow("✍️ Estilo de escritura", WritingStyle.entries, s.style, { it.label }) { v ->
                onChange { it.copy(style = v) }
            }
        }
    }
}

/** Fila con título y chips seleccionables (genérica para cualquier enum). */
@Composable
private fun <T> OptionRow(
    title: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column(Modifier.padding(top = 12.dp)) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = KwaiInk)
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { option ->
                KwaiChip(label(option), option == selected) { onSelect(option) }
            }
        }
    }
}

@Composable
private fun KwaiChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) KwaiPurple else KwaiLavender)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) Color.White else KwaiPurpleDark
        )
    }
}

/** Zona central: aquí aparece el mensaje generado (con animación al cambiar). */
@Composable
private fun MessageCard(message: SavedMessage?, isFav: Boolean) {
    val shape = RoundedCornerShape(30.dp, 30.dp, 30.dp, 8.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .heightIn(min = 220.dp)
            .shadow(10.dp, shape)
            .clip(shape)
            .background(Color.White)
            .border(2.dp, Brush.linearGradient(listOf(KwaiPink, KwaiPurple, KwaiSky)), shape)
            .padding(22.dp),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = message,
            transitionSpec = {
                (fadeIn(tween(250)) + scaleIn(initialScale = 0.8f, animationSpec = tween(250))) togetherWith
                    fadeOut(tween(120))
            },
            label = "message-swap"
        ) { m ->
            if (m == null) {
                Text(
                    "Aquí aparecerá tu mensaje caótico ✨\n\nPulsa 🎲 GENERAR CAOS",
                    fontSize = 18.sp,
                    lineHeight = 26.sp,
                    textAlign = TextAlign.Center,
                    color = KwaiInk.copy(alpha = 0.55f)
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        m.text,
                        fontSize = 21.sp,
                        lineHeight = 30.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        color = KwaiInk
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(
                        (if (isFav) "⭐ " else "") + m.badge(),
                        fontSize = 12.sp,
                        color = KwaiPurple
                    )
                }
            }
        }
    }
}

/** Botón enorme + botones de copiar, generar otro, favorito y compartir. */
@Composable
private fun ActionArea(
    hasMessage: Boolean,
    isFav: Boolean,
    onGenerate: () -> Unit,
    onCopy: () -> Unit,
    onAnother: () -> Unit,
    onFav: () -> Unit,
    onShare: () -> Unit
) {
    // Latido suave del botón principal.
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse-scale"
    )

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BigButton(
            text = "🎲 GENERAR CAOS",
            brush = Brush.horizontalGradient(listOf(KwaiPurple, KwaiPink)),
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = pulse
                    scaleY = pulse
                },
            height = 76.dp,
            fontSize = 26.sp,
            onClick = onGenerate
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton(
                text = "📋 COPIAR MENSAJE",
                brush = Brush.horizontalGradient(listOf(KwaiSky, Color(0xFF7FA8FF))),
                modifier = Modifier.weight(1f),
                enabled = hasMessage,
                onClick = onCopy
            )
            BigButton(
                text = "💥 GENERAR OTRO",
                brush = Brush.horizontalGradient(listOf(KwaiPink, Color(0xFFFF9A8B))),
                modifier = Modifier.weight(1f),
                onClick = onAnother
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton(
                text = if (isFav) "⭐ EN FAVORITOS" else "☆ MARCAR FAVORITO",
                brush = if (isFav) {
                    Brush.horizontalGradient(listOf(Color(0xFFFFB74D), KwaiPink))
                } else {
                    Brush.horizontalGradient(listOf(KwaiPurple, Color(0xFF9E7BFF)))
                },
                modifier = Modifier.weight(1f),
                enabled = hasMessage,
                onClick = onFav
            )
            BigButton(
                text = "📤 COMPARTIR",
                brush = Brush.horizontalGradient(listOf(KwaiSky, KwaiPurple)),
                modifier = Modifier.weight(1f),
                enabled = hasMessage,
                onClick = onShare
            )
        }
    }
}

/** Botón grande con degradado, sombra y efecto de rebote al pulsar. */
@Composable
private fun BigButton(
    text: String,
    brush: Brush,
    modifier: Modifier = Modifier,
    height: Dp = 56.dp,
    fontSize: TextUnit = 13.sp,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(26.dp)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed) 0.94f else 1f, label = "press-scale")

    Box(
        modifier
            .height(height)
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
                alpha = if (enabled) 1f else 0.45f
            }
            .shadow(if (enabled) 6.dp else 0.dp, shape)
            .clip(shape)
            .background(brush)
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}

// ═══════════════════════════ PESTAÑAS: FAVORITOS E HISTORIAL ═══════════════════════════

@Composable
private fun FavoritesScreen(vm: MainViewModel) {
    MessageList(
        emptyEmoji = "⭐",
        emptyText = "Aún no tienes favoritos.\nPulsa ☆ MARCAR FAVORITO en un mensaje que te encante.",
        messages = vm.favorites,
        vm = vm
    )
}

@Composable
private fun HistoryScreen(vm: MainViewModel) {
    MessageList(
        emptyEmoji = "🕘",
        emptyText = "Todavía no hay historial.\nGenera algo de caos y aparecerá aquí.",
        messages = vm.history,
        vm = vm,
        topContent = { ClearButton { vm.clearHistory() } }
    )
}

/** Lista vertical de mensajes guardados (la usan favoritos e historial). */
@Composable
private fun MessageList(
    emptyEmoji: String,
    emptyText: String,
    messages: List<SavedMessage>,
    vm: MainViewModel,
    topContent: (@Composable () -> Unit)? = null
) {
    val context = LocalContext.current

    if (messages.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(emptyEmoji, fontSize = 56.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    emptyText,
                    fontSize = 16.sp,
                    lineHeight = 22.sp,
                    textAlign = TextAlign.Center,
                    color = KwaiInk.copy(alpha = 0.7f)
                )
            }
        }
    } else {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (topContent != null) {
                item { topContent() }
            }
            items(messages) { m ->
                MessageItem(
                    message = m,
                    isFav = vm.isFavorite(m.text),
                    onFav = { vm.toggleFavorite(m) },
                    onCopy = { copyToClipboard(context, m.text) },
                    onShare = { shareText(context, m.text) }
                )
            }
        }
    }
}

@Composable
private fun MessageItem(
    message: SavedMessage,
    isFav: Boolean,
    onFav: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White)
            .padding(16.dp)
    ) {
        Text(message.text, fontSize = 17.sp, lineHeight = 24.sp, color = KwaiInk)
        Spacer(Modifier.height(10.dp))
        Text(
            "${message.badge()} · ${relativeTime(message.createdAt)}",
            fontSize = 12.sp,
            color = KwaiPurple
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniAction(if (isFav) "⭐" else "☆", onFav)
            MiniAction("📋", onCopy)
            MiniAction("📤", onShare)
        }
    }
}

@Composable
private fun MiniAction(emoji: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(KwaiLavender)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(emoji, fontSize = 20.sp)
    }
}

@Composable
private fun ClearButton(onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.85f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text("🧹 Borrar historial", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KwaiPurpleDark)
    }
}

// ═══════════════════════════ BARRA INFERIOR ═══════════════════════════

@Composable
private fun BottomBar(selected: Tab, favoriteCount: Int, onSelect: (Tab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.9f))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        BottomItem("🎲", "Generar", selected == Tab.GENERATE, Modifier.weight(1f)) {
            onSelect(Tab.GENERATE)
        }
        BottomItem("⭐", "Favoritos ($favoriteCount)", selected == Tab.FAVORITES, Modifier.weight(1f)) {
            onSelect(Tab.FAVORITES)
        }
        BottomItem("🕘", "Historial", selected == Tab.HISTORY, Modifier.weight(1f)) {
            onSelect(Tab.HISTORY)
        }
    }
}

@Composable
private fun BottomItem(
    emoji: String,
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(if (selected) KwaiLavenderDeep else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 22.sp)
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = KwaiPurpleDark,
            maxLines = 1
        )
    }
}

// ═══════════════════════════ UTILIDADES ═══════════════════════════

/** Copia el texto al portapapeles y avisa con un mensajito. */
private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("Kwai Generator 3000", text))
    Toast.makeText(context, "¡Copiado! 📋", Toast.LENGTH_SHORT).show()
}

/** Abre el menú de compartir de Android con el mensaje. */
private fun shareText(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "Compartir mensaje"))
}

/** "hace 5 minutos", "ayer", etc., en el idioma del teléfono. */
private fun relativeTime(millis: Long): String =
    DateUtils.getRelativeTimeSpanString(
        millis,
        System.currentTimeMillis(),
        DateUtils.MINUTE_IN_MILLIS
    ).toString()
