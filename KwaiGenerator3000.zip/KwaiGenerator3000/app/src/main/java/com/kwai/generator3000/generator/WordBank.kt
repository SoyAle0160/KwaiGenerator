package com.kwai.generator3000.generator

import com.kwai.generator3000.Personality
import com.kwai.generator3000.Topic
import kotlin.random.Random

/** Bancos de palabras compartidos por todas las personalidades. */
object WordBank {

    /** Caritas kaomoji (solo caracteres que las fuentes de Samsung muestran bien). */
    val kaomojis = listOf(
        "(≧◡≦)", "(｡◕‿◕｡)", "(=^･ω･^=)", "(>_<)", "(T_T)", "(╥﹏╥)", "(*´▽`*)",
        "ヽ(>∀<☆)ノ", "(⁄ ⁄>⁄ ▽ ⁄<⁄ ⁄)", "(ノ°益°)ノ", "(°ロ°)", "(¬_¬)", "(・ω・)",
        "(づ｡◕‿‿◕｡)づ", "(*^▽^*)", "\\(^o^)/", "(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧", "(；一_一)", "(≧▽≦)",
        "(╯°□°）╯︵ ┻━┻", "(´• ω •`)", "(^ω^)", "(*>◡<*)", "(o^▽^o)"
    )

    /** Expresiones típicas de chat kawaii. */
    val expressions = listOf(
        "UwU", "OwO", "nya~", "nyaa", "miau", "kawaii", "onichan", "senpai", ">///<", "QwQ",
        "T^T", ":3", ">w<", "ARRR", "NYAAAA", "uwu", ";w;", "XD", "jsjsjs", "awa", "ufufu",
        "kyaa", "nyan"
    )

    val interjections = listOf(
        "bro", "oye", "ay", "no pero", "espera", "literal", "ok", "mmm", "uff", "wow",
        "oigan", "ojo", "jajaja", "ya", "bueno", "amigo"
    )

    val japanese = listOf(
        "sugoi", "nani", "baka", "yatta", "gomen", "daijoubu", "ganbatte", "itadakimasu",
        "doki doki", "kyaa", "ohayo", "kawaii", "arigatou"
    )

    /** Comidas sin artículo (para "quiero ___"). */
    val foods = listOf(
        "ramen", "onigiris", "pizza", "helado", "papitas", "boba tea", "takoyakis",
        "pastel de fresa", "empanadas", "chocolate caliente", "nuggets", "galletitas",
        "arroz con pollo", "fideos", "tortitas", "palomitas", "dulces", "sándwich"
    )

    /** Animales con artículo (para "vi ___"). */
    val animals = listOf(
        "un gatito", "un perrito", "un pato", "un hámster", "un capibara", "un pingüino",
        "un axolote", "un conejito", "una tortuga", "un pollito", "una paloma con actitud", "un panda"
    )

    /** Sujetos absurdos (siempre en singular). */
    val absurdNouns = listOf(
        "una tostadora emocional", "un pingüino con corbata", "mi abuela ninja",
        "el espíritu del lunes", "un pato filósofo", "un wifi sin alma", "el último onigiri",
        "una nube con ambición", "un dragón de bolsillo", "el sofá malvado",
        "un calcetín con identidad propia", "el gato del espacio", "una pizza con sueños",
        "mi cargador desaparecido", "un hámster astronauta", "el vecino de la dimensión 7",
        "una cuchara rebelde", "un meteorito con hambre", "el capibara supremo",
        "una lámpara dramática", "un robot que llora", "un sapo aristócrata",
        "el manual de instrucciones", "una papa con complejos",
        "el club secreto de los cojines", "un fantasma tímido"
    )

    /** Acciones absurdas en pasado, tercera persona del singular. */
    val absurdActions = listOf(
        "se declaró en bancarrota emocional", "abrió una academia de baile para nubes",
        "inventó el lunes sin tarea", "se casó con un meteorito",
        "negoció la paz mundial con un sándwich", "entró a mi casa y se llevó mis calcetines",
        "ganó un torneo de miradas incómodas", "se fue de vacaciones a mi refrigerador",
        "fundó una religión basada en los fideos", "aprendió a hablar y solo dice nya",
        "se perdió en el capítulo 12 de mi vida", "dio un discurso sobre la importancia de las siestas",
        "descubrió que el piso es lava", "me dejó en visto cósmico", "se enamoró de un microondas",
        "aprobó el examen sin haber estudiado", "bailó la macarena en el techo"
    )

    /** Lugares absurdos con preposición ("en la cima del refrigerador"). */
    val absurdLocations = listOf(
        "en la cima del refrigerador", "dentro de mi mochila", "en el fondo de tu sopa",
        "en el planeta Queso", "detrás de la nevera", "en la dimensión de los calcetines perdidos",
        "en el último piso del arcoíris", "debajo de la cama de un astronauta",
        "en la oficina de las nubes", "encima de una pizza gigante"
    )

    /** Lugares absurdos sin preposición ("presidente de ___"). */
    val absurdPlaces = listOf(
        "el planeta Queso", "la dimensión de los calcetines perdidos", "el último piso del arcoíris",
        "mi mochila", "la nevera", "el club de las nubes", "la Luna", "el país de las siestas"
    )

    /** Palabras que el Glitch Humano escribe en binario. */
    val binaryWords = listOf("hola", "nya", "uwu", "ayuda", "pan", "kawaii")
}

/** Temas: frases cortas ("el ramen") y oraciones completas para cada tema. */
object ThemeBank {

    private val animeNouns = listOf(
        "ese opening", "el protagonista", "mi waifu", "el villano principal", "el capítulo final",
        "el episodio de relleno", "ese plot twist", "el torneo de poder", "el episodio de playa",
        "el festival escolar", "el club de cocina", "el uniforme escolar", "el sensei",
        "esa transformación", "mi anime favorito"
    )
    private val animeSentences = listOf(
        "el protagonista otra vez gritó el nombre de su ataque",
        "ese plot twist me dejó mirando el techo",
        "el opening es mejor que toda mi semana",
        "justo cuando iba a ganar llegó el episodio de playa",
        "el villano tenía razón y nadie lo quiere admitir",
        "siempre hay un festival escolar cuando menos lo esperas",
        "el protagonista despertó un poder nuevo por décima vez",
        "el mejor amigo del protagonista siempre llega tarde pero llega",
        "en los animes todos aprenden a cocinar en un solo episodio",
        "nadie me avisó que ese personaje iba a desaparecer"
    )

    private val foodNouns = listOf(
        "el ramen", "los onigiris", "la pizza con piña", "el helado de fresa", "las papitas",
        "el boba tea", "los takoyakis", "el pastel de fresa", "las empanadas",
        "el chocolate caliente", "mi sándwich", "los nuggets", "las galletitas",
        "el arroz con pollo", "los fideos"
    )
    private val foodSentences = listOf(
        "tengo hambre pero también flojera de cocinar",
        "me comí tres onigiris y aún siento un vacío existencial",
        "ese ramen me miró y no pude resistirme",
        "la pizza con piña es un tema que divide familias",
        "el helado se derritió antes de que pudiera comérmelo",
        "siempre hay espacio para el postre, es ciencia",
        "mi estómago hace ruidos que parecen un idioma",
        "el último pedazo de pastel desapareció y nadie sabe nada",
        "abrí el refrigerador esperando magia y encontré una cebolla",
        "los fideos instantáneos son mi lenguaje del amor"
    )

    private val animalNouns = listOf(
        "el gatito", "ese perrito", "un pato", "el hámster", "el capibara", "el pingüino",
        "el gato del vecino", "las palomas", "un axolote", "el conejito", "la tortuga", "el pollito"
    )
    private val animalSentences = listOf(
        "un pato me miró fijamente y sentí que sabía mis secretos",
        "el gato se sentó en mi teclado y escribió mejor que yo",
        "el capibara no tiene preocupaciones y yo tampoco... mentira, sí tengo",
        "las palomas se organizan como una banda y yo lo noto",
        "vi un perrito con botitas y mi día mejoró",
        "el axolote sonríe porque sabe que no tiene tarea",
        "el hámster corre toda la noche y no llega a ninguna parte, igual que yo",
        "un pingüino caminando es lo más elegante del mundo",
        "mi gato me juzga en silencio cada vez que como",
        "el conejito movió la nariz y yo me rendí"
    )

    private val shameNouns = listOf(
        "mi vergüenza", "ese mensaje que mandé", "mi cara roja", "el audio equivocado",
        "mi crush", "esa conversación", "el saludo fallido", "mi tropezón",
        "el sticker equivocado", "mi risa nerviosa"
    )
    private val shameSentences = listOf(
        "mandé un sticker al grupo equivocado y ahora quiero mudarme de planeta",
        "me dijeron 'hola' y me trabé como computadora vieja",
        "se me cayó el celular en plena clase y todos escucharon",
        "saludé a alguien que no me estaba saludando a mí",
        "me dijeron 'que te vaya bien' y respondí 'igualmente' sin pensar",
        "me reí en el momento más serio del día",
        "empujé la puerta que decía 'jalar' frente a todos",
        "grité 'presente' en una clase que no era la mía",
        "me equivoqué de nombre al saludar y fingí que era un chiste",
        "contesté un audio en voz alta creyendo que estaba solo"
    )

    private val screamNouns = listOf(
        "este grito", "mi garganta", "mis vecinos", "el micrófono", "mi alma", "mi voz",
        "el eco", "esa nota aguda"
    )
    private val screamSentences = listOf(
        "grito en silencio porque mi mamá está durmiendo",
        "grité tan fuerte que el wifi se reinició",
        "mis vecinos ya me conocen por mis gritos de emoción",
        "gritar con un cojín en la cara es mi deporte favorito",
        "intenté gritar pero me salió un pitido de tetera",
        "el eco de mi grito volvió con respuesta",
        "ese grito no fue por miedo, fue por puro hype",
        "voy a gritar hasta que el gato me felicite"
    )

    private val randomNouns = listOf(
        "la luna", "el wifi", "mi sombra", "el lunes", "la tarea", "esa nube", "mi cargador",
        "el refrigerador", "un calcetín", "la silla", "el espejo", "el cojín"
    )
    private val randomSentences = listOf(
        "las nubes son solo agua con ambición",
        "mi tostadora y yo tenemos una relación complicada",
        "hoy desperté con ganas de ser un pingüino",
        "el lunes debería ser ilegal",
        "alguien vio mi cargador o se fue a otra dimensión",
        "si los calcetines desaparecen, ¿adónde van?",
        "el piso es lava desde hace {n} minutos",
        "las escaleras me odian, lo sé",
        "no sé quién inventó la tarea, pero tengo preguntas",
        "un día voy a entender cómo funciona el wifi",
        "mi sombra me dejó en visto",
        "los jueves son los viernes con complejo de inferioridad"
    )

    // "Sin tema" mezcla todos los temas.
    private val allNouns =
        animeNouns + foodNouns + animalNouns + shameNouns + screamNouns + randomNouns
    private val allSentences =
        animeSentences + foodSentences + animalSentences + shameSentences + screamSentences + randomSentences

    private fun nounsOf(topic: Topic): List<String> = when (topic) {
        Topic.ANIME -> animeNouns
        Topic.FOOD -> foodNouns
        Topic.ANIMALS -> animalNouns
        Topic.SHAME -> shameNouns
        Topic.SCREAMS -> screamNouns
        Topic.RANDOM -> randomNouns
        Topic.NONE -> allNouns
    }

    private fun sentencesOf(topic: Topic): List<String> = when (topic) {
        Topic.ANIME -> animeSentences
        Topic.FOOD -> foodSentences
        Topic.ANIMALS -> animalSentences
        Topic.SHAME -> shameSentences
        Topic.SCREAMS -> screamSentences
        Topic.RANDOM -> randomSentences
        Topic.NONE -> allSentences
    }

    fun noun(topic: Topic, rnd: Random): String = nounsOf(topic).random(rnd)

    fun sentence(topic: Topic, rnd: Random): String = sentencesOf(topic).random(rnd)
}

/** Emojis que acompañan a cada personalidad. */
object EmojiPools {

    private val general = listOf(
        "✨", "💜", "🌸", "💥", "🔥", "😭", "💀", "🥺", "😳", "🎀", "🐱", "🐾", "🍡", "🌀",
        "👀", "😹", "💫", "🌈", "⭐", "🍜"
    )
    private val neko = listOf("🐱", "🐾", "😻", "😽", "💜", "🌸", "🐟", "🍥", "✨", "🎀", "😺", "🥛")
    private val senpai = listOf("😳", "🌸", "💗", "🥺", "👉", "👈", "😖", "🍙", "✨", "🎀", "💞", "🙈")
    private val polites = listOf("💀", "😭", "🔥", "🗣️", "‼️", "🤯", "😂", "🫠", "👁️", "💥", "🤡", "⚡")
    private val glitch = listOf("👾", "🌀", "⚠️", "💾", "🧠", "📡", "🔌", "🤖", "💻", "❌", "🔁", "📟")
    private val chaosGod = listOf("🦆", "🍕", "🛸", "🪐", "🥔", "🧀", "🐧", "🦕", "🪄", "🎪", "🧦", "🌮")

    fun forPersonality(p: Personality): List<String> = when (p) {
        Personality.POLITES -> polites + general.take(6)
        Personality.NEKO -> neko + general.take(6)
        Personality.SENPAI -> senpai + general.take(6)
        Personality.GLITCH -> glitch + general.take(6)
        Personality.RANDOM_GOD -> chaosGod + general.take(6)
        Personality.MIX -> general + neko + senpai + polites + glitch + chaosGod
    }
}
