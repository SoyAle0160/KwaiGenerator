package com.kwai.generator3000

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Guarda todo en el propio teléfono (SharedPreferences): ajustes, favoritos e historial.
 * No usa internet ni bases de datos externas.
 */
class Storage(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("kwai_generator_prefs", Context.MODE_PRIVATE)

    // ───────── Ajustes ─────────

    fun loadSettings(): GenSettings {
        val raw = prefs.getString(KEY_SETTINGS, null) ?: return GenSettings()
        return try {
            val o = JSONObject(raw)
            GenSettings(
                personality = enumOr(o.optString("personality"), Personality.MIX),
                chaos = enumOr(o.optString("chaos"), Chaos.CHAOTIC),
                length = enumOr(o.optString("length"), Length.MEDIUM),
                emoji = enumOr(o.optString("emoji"), EmojiAmount.NORMAL),
                topic = enumOr(o.optString("topic"), Topic.NONE),
                style = enumOr(o.optString("style"), WritingStyle.NORMAL)
            )
        } catch (e: Exception) {
            GenSettings()
        }
    }

    fun saveSettings(s: GenSettings) {
        val o = JSONObject()
            .put("personality", s.personality.name)
            .put("chaos", s.chaos.name)
            .put("length", s.length.name)
            .put("emoji", s.emoji.name)
            .put("topic", s.topic.name)
            .put("style", s.style.name)
        prefs.edit().putString(KEY_SETTINGS, o.toString()).apply()
    }

    // ───────── Listas de mensajes (favoritos / historial) ─────────

    fun loadMessages(key: String): List<SavedMessage> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SavedMessage(
                    id = o.optLong("id"),
                    text = o.optString("text"),
                    personality = o.optString("personality"),
                    createdAt = o.optLong("createdAt")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveMessages(key: String, list: List<SavedMessage>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("text", m.text)
                    .put("personality", m.personality)
                    .put("createdAt", m.createdAt)
            )
        }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    // ───────── Contador de caos generado ─────────

    var totalGenerated: Int
        get() = prefs.getInt(KEY_TOTAL, 0)
        set(value) {
            prefs.edit().putInt(KEY_TOTAL, value).apply()
        }

    /** Convierte un nombre guardado en su enum; si no existe, usa el valor por defecto. */
    private inline fun <reified T : Enum<T>> enumOr(name: String, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: fallback

    companion object {
        const val KEY_SETTINGS = "settings"
        const val KEY_FAVORITES = "favorites"
        const val KEY_HISTORY = "history"
        private const val KEY_TOTAL = "total_generated"
    }
}
