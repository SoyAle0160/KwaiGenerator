package com.kwai.generator3000.generator

import com.kwai.generator3000.Personality

/**
 * Paquete de plantillas de una personalidad.
 *
 * Espacios que se rellenan solos:
 *  {kao} kaomoji · {expr} expresión kawaii · {grito} grito · {tema} frase corta del tema ·
 *  {tema_frase} oración del tema · {rnd_n} sujeto absurdo · {rnd_a} acción absurda ·
 *  {rnd_l} lugar con preposición · {rnd_p} lugar sin preposición · {comida} · {animal} ·
 *  {interj} · {jp} palabra japonesa · {bin} palabra en binario · {n} número.
 * Con "?" (por ejemplo {kao?}) el espacio aparece solo a veces.
 */
class PersonaPack(
    val openers: List<String>,
    val actions: List<String>,
    val reactions: List<String>,
    val statements: List<String>,
    val shifts: List<String>,
    val closers: List<String>,
    val bits: List<String>
)

object PersonaPacks {

    /** Polites.exe: reacciones exageradas, gritos y cambios de tema. */
    private val polites = PersonaPack(
        openers = listOf(
            "AAAAAAA ESPERA",
            "oye oye oye oye",
            "NO PERO ESCUCHEN",
            "ok ok ok ok ok",
            "Polites.exe iniciando... {grito}",
            "bro.",
            "jajajajaja no",
            "HOLA?? ¿HAY ALGUIEN??",
            "pausa, pausa, pausa",
            "ya, tengo que contarles algo",
            "{interj}, {interj}, {interj}",
            "ATENCIÓN GRUPO"
        ),
        actions = listOf(
            "me caí de la silla y no sé por qué",
            "estoy llorando en el piso de la risa",
            "mi cerebro hizo crash",
            "me quedé mirando la pared 5 minutos completos",
            "grité tan fuerte que mi vecino me gritó de vuelta",
            "se me cayó el celular en la cara otra vez",
            "me reí tan fuerte que se me salió el aire por la nariz",
            "abrí el refri por quinta vez sin tener hambre",
            "aplaudí solo en mi cuarto sin razón",
            "salí a correr y volví en 40 segundos"
        ),
        reactions = listOf(
            "ESO ES ILEGAL",
            "no puedo con esto, de verdad",
            "qué clase de brujería es esta",
            "ME MUERO, ME MUERO, ME MUERO",
            "literal mi alma salió de mi cuerpo",
            "esto es mejor que el final de un anime {kao?}",
            "no le encuentro lógica y me encanta",
            "NO ES POSIBLE {grito}",
            "jajaja pero por qué {expr?}",
            "esto es arte, señoras y señores"
        ),
        statements = listOf(
            "alguien explíqueme lo de {tema} {kao?}",
            "ESTOY PENSANDO EN {tema} Y NO PARO",
            "lo único que sé es que {tema_frase}",
            "acabo de recordar que {tema_frase}",
            "no dejo de pensar en {tema} desde ayer",
            "tengo dudas sobre {tema} y nadie me las quita",
            "me dijeron que {tema_frase} y yo aquí tan tranquilo",
            "{tema}: un antes y un después en mi vida",
            "no sé ustedes pero {tema_frase}",
            "POR QUÉ {tema} Y NADIE ME DIJO NADA"
        ),
        shifts = listOf(
            "cambiando de tema: ¿alguien tiene {comida}?",
            "ah y otra cosa, {rnd_n} {rnd_a}",
            "bueno ya, ¿qué almorzamos hoy?",
            "espera, esto no era el grupo de la tarea",
            "pero en otras noticias, {tema_frase}",
            "¿alguien más huele a {comida}? ¿solo yo?"
        ),
        closers = listOf(
            "jsjsjs {kao?}",
            "xdxdxd ya no sé ni qué escribo",
            "bueno me fui",
            "adiós, me voy a gritarle a una almohada",
            "Polites.exe ha dejado de funcionar",
            "luego sigo, mi cerebro está en mantenimiento",
            "eso era todo, gracias por su atención {expr?}",
            "{grito} ok ya",
            "fin del comunicado oficial",
            "reiniciando Polites.exe... 3... 2... 1... {grito}"
        ),
        bits = listOf(
            "{grito}",
            "{interj}??",
            "espera qué",
            "WAIT",
            "jajajajajajajaja",
            "NO. NO. NO.",
            "¿{n} QUÉ?",
            "{rnd_n}??? en serio???"
        )
    )

    /** Neko Kawaii: nya, miau, caritas de gato y ternura. */
    private val neko = PersonaPack(
        openers = listOf(
            "Nyaa~ holi holi {kao?}",
            "Miau miau, ¿me extrañaron? UwU",
            "Nya nya nya nya",
            "*aparece de la nada* nya~",
            "Holi nyan~ {expr?}",
            "Hola hola, soy el gatito del grupo :3",
            "UwU buenos días nya",
            "Miaaauuu~"
        ),
        actions = listOf(
            "*mueve la colita felizmente*",
            "*se sienta encima de tu teclado*",
            "*ronronea muy fuerte* purr purr",
            "*amasa la manta con sus patitas*",
            "*empuja un vaso de la mesa mirándote fijo*",
            "*persigue un puntito láser imaginario*",
            "*parpadea lento en señal de cariño*",
            "*se estira como pan de molde*",
            "*se esconde dentro de una caja de zapatos*"
        ),
        reactions = listOf(
            "eso fue kawaii a nivel peligroso nya",
            "me derrito de ternura UwU",
            "mi corazón hace miau miau",
            "quiero {comida} ahora mismo nya",
            "qué cosita más linda >w<",
            "nya, nya, NYAAAAA",
            "kawaii, kawaii, kawaiiii {kao?}",
            "UwU me dejaste sin palabras, solo nya"
        ),
        statements = listOf(
            "{tema}... ¡qué cosa tan adorable, nya! {kao?}",
            "un gatito como yo opina que {tema_frase}",
            "me puse a pensar en {tema} y mi colita se movió sola",
            "nya, ¿sabías que {tema_frase}? :3",
            "pensar en {tema} me hace ronronear {expr?}",
            "los gatitos sabemos que {tema_frase}",
            "hoy solo pienso en {tema}, miau",
            "mis bigotes detectaron algo: {tema_frase}"
        ),
        shifts = listOf(
            "cambiando de tema nya: ¿tienen {comida}? miau",
            "oigan, vi {animal} y quedé en shock UwU",
            "hablando de otra cosa, quiero que me rasquen detrás de la oreja",
            "{rnd_n} apareció {rnd_l} y ahora vive con nosotros, nya",
            "psst, ¿quieren oír un secreto? ¡{tema_frase}!"
        ),
        closers = listOf(
            "nya~ ♡",
            "miau :3",
            "¿me das un atunsito? UwU",
            "ñam ñam {kao?}",
            "purr purr, buenas noches nyan",
            "hasta luego nyan~ {kao}",
            "me voy a dormir {n} horas en el sofá, nya",
            "te quiero mucho, nya >w<"
        ),
        bits = listOf(
            "nya?",
            "miau miau miau",
            "{grito}",
            "UwU",
            "*ruido de gato confundido*",
            "NYAAAAAAA",
            "*tira algo al piso*"
        )
    )

    /** Onichan / Senpai: tartamudeos, vergüenza fingida, >///< y 👉👈. */
    private val senpai = PersonaPack(
        openers = listOf(
            "O-onichan...",
            "S-senpai... e-eh...",
            "E-etto... ano...",
            "K-kyaa~",
            "N-no me mires así, ¿sí?",
            "Onichan, ¡te traje un onigiri! e-es que... bueno...",
            "Ano... senpai... t-tengo que decirte algo",
            "B-baka... no es lo que piensas"
        ),
        actions = listOf(
            "*se tapa la cara con las manos*",
            "*juega con sus dedos nerviosamente*",
            "*desvía la mirada con las mejillas rojas*",
            "*se esconde detrás de la puerta*",
            "*agarra tu manga muy suavecito*",
            "*esconde la cara dentro de la mochila*",
            "*se abanica la cara con un cuaderno*",
            "*tropieza con sus propios pies*"
        ),
        reactions = listOf(
            "n-no es que me importe ni nada, ¿vale?",
            "no te creas especial, b-baka",
            "e-estoy bien, es que hace calor aquí... ¿verdad?",
            "mi corazón hace doki doki, doki doki",
            "n-no me hagas repetirlo, por favor",
            "s-senpai me notó... ¡me notó! ¡KYAAA!",
            "e-es que eres muy... muy... ¡olvídalo! >///<",
            "no no no, ¡nadie se sonrojó! es el sol"
        ),
        statements = listOf(
            "e-es que {tema_frase}... y yo...",
            "{tema}... n-nunca pensé hablar de eso contigo, senpai",
            "o-onichan, ¿tú sabías que {tema_frase}?",
            "dicen que {tema_frase}, pero yo no dije nada, ¿eh?",
            "pensé en {tema} todo el día... n-no es raro, ¿verdad?",
            "s-si te gusta hablar de {tema}, entonces a mí también... digo, ¡no! ¡es coincidencia!",
            "todos dicen que {tema_frase} y yo solo asentí {kao?}",
            "e-estudié toda la noche sobre {tema}... para nada por ti"
        ),
        shifts = listOf(
            "a-ah, otra cosa: ¿alguien tiene {comida}? s-solo preguntaba",
            "c-cambiando de tema... {rnd_n} {rnd_a}",
            "e-eh, mejor hablemos de otra cosa... ¿vieron {tema}?",
            "ano, ¿alguien vio mi cuaderno? no, mentira, sí lo tengo"
        ),
        closers = listOf(
            ">///<",
            "👉👈",
            "b-baka... >///<",
            "n-nos vemos mañana, senpai... {kao?}",
            "tsk... ¡no es por ti!",
            "(⁄ ⁄>⁄ ▽ ⁄<⁄ ⁄)",
            "me voy corriendo, ¡adiós! *huye*",
            "g-gracias por escucharme... onichan 👉👈"
        ),
        bits = listOf(
            "k-kyaaa",
            "a-ano...",
            "e-eh?!",
            "B-BAKA",
            "{jp}...",
            "*se pone como tomate*"
        )
    )

    /** Glitch Humano: errores de sistema, binario y cambios bruscos de personalidad. */
    private val glitch = PersonaPack(
        openers = listOf(
            "ERROR 404: saludo no encontrado",
            "cargando personalidad... {n}%",
            "h-h-hola? hello? konnichiwa?",
            "{bin}",
            "reiniciando alma.exe...",
            "bip bop bip: ¿{interj}?",
            "SISTEMA: usuario detectado... usuario confundido",
            "▓▒░ hola ░▒▓"
        ),
        actions = listOf(
            "[modo gato activado] nya [modo robot activado] BEEP BOOP",
            "mi cerebro está en modo avión desde las {n}:{n}",
            "ejecuté {rnd_n} sin querer",
            "borré mis recuerdos para hacer espacio para {comida}",
            "actualicé mi personalidad a la versión {n}.{n} y ahora no entiendo nada",
            "me llegó una notificación de mi propia conciencia",
            "mezclé mis pensamientos en la licuadora",
            "me quedé en loop diciendo 'ya voy' desde ayer"
        ),
        reactions = listOf(
            "ERROR: emoción no encontrada, usando emoción de reemplazo: {grito}",
            "no entiendo pero acepto {kao?}",
            "esto no compila pero me gusta",
            "sistema sobrecargado de ternura",
            "mi lógica dijo adiós y se llevó el wifi",
            "WARNING: demasiada {comida} en el sistema",
            "[ERROR] [ERROR] [ERROR] todo bien :)"
        ),
        statements = listOf(
            "ERROR detectado en {tema}, repito: ERROR",
            "dato inútil: {tema_frase}",
            "mi lógica interna dice que {tema_frase} pero mi corazón dice 'ñam'",
            "según mis cálculos, {tema} + {rnd_n} = caos total",
            "detecté {tema} en el sistema, repito: {tema}",
            "acabo de descubrir que {tema_frase} y no sé si reír o reiniciar",
            "mi base de datos dice que {tema_frase}, aunque está corrupta",
            "esto de {tema} me tiene en pantalla azul"
        ),
        shifts = listOf(
            "[CAMBIO DE PERSONALIDAD] ahora soy {rnd_n}",
            "ERROR: tema anterior eliminado. Nuevo tema: {tema}",
            "pantalla azul... ahora hablemos de {comida}",
            "[modo abuelita activado] ay mijito, ¿ya comiste {comida}?",
            "alt + f4 a mi dignidad, siguiente tema: {tema}"
        ),
        closers = listOf(
            "fin del mensaje... o no... o sí... ¿{interj}?",
            "apagando sistema... apagando... apagando... nya",
            "guardando cambios... ERROR... cambios eliminados",
            "{bin}",
            "ctrl+z a todo lo que dije",
            "reinicio completado. ¿quién soy? {kao?}",
            "[conexión perdida con la cordura]",
            "gracias por usar Glitch Humano™, su dolor de cabeza es nuestra prioridad"
        ),
        bits = listOf(
            "bip bop",
            "▓▒░█▓▒░",
            "01001110 01011001 01000001",
            "%\$#@ ERROR @#\$%",
            "t-t-t-te estoy hablando desde el fu-fu-futuro",
            "[carga... carga... carga...]",
            "NULL NULL NULL"
        )
    )

    /** Dios del Random: humor absurdo y combinaciones inesperadas. */
    private val randomGod = PersonaPack(
        openers = listOf(
            "El Dios del Random ha hablado:",
            "Por decreto divino:",
            "Atención, mortales:",
            "Última hora desde el planeta Queso:",
            "Escuchen, simples humanos:",
            "Noticia cósmica de último minuto:",
            "Tengo una revelación y nadie la pidió:",
            "Dato aleatorio de nivel divino:"
        ),
        actions = listOf(
            "{rnd_n} {rnd_a} {rnd_l}",
            "ayer vi cómo {rnd_n} {rnd_a}",
            "{rnd_n} y {rnd_n} están juntos {rnd_l}",
            "me dijeron que {rnd_n} {rnd_a}, y les creo",
            "en una dimensión paralela, {rnd_n} {rnd_a}",
            "desde hoy {rnd_n} es el nuevo presidente de {rnd_p}",
            "un sabio dijo que {rnd_n} {rnd_a} y nadie lo detuvo"
        ),
        reactions = listOf(
            "y así es como funciona el universo {kao?}",
            "esto no tiene sentido y por eso es perfecto",
            "la lógica ha sido derrotada por {rnd_n}",
            "nadie lo vio venir, ni siquiera yo",
            "que alguien le avise a {rnd_n}",
            "el multiverso aprueba este mensaje",
            "{rnd_n} aplaude desde {rnd_p}",
            "y todo esto por culpa de {comida}"
        ),
        statements = listOf(
            "{tema} y {rnd_n} deberían hacer un dúo, lo siento pero es así",
            "pensar en {tema} y en {rnd_n} al mismo tiempo rompe la física",
            "ordeno feriado nacional en honor a {tema}",
            "el secreto del universo: {tema_frase}",
            "entre {tema} y {rnd_n}, elijo a ambos y a ninguno",
            "prohíbo oficialmente que alguien hable mal de {tema}",
            "he visto el futuro: {tema_frase}",
            "mezclar {tema} con {comida} es mi mejor idea del año"
        ),
        shifts = listOf(
            "cambiando de tema porque puedo: {rnd_n}",
            "hablando de nada: {tema_frase}",
            "sin relación alguna, pero {rnd_n} {rnd_a}",
            "pregunta importante: ¿{rnd_n} o {rnd_n}? elijan con sabiduría"
        ),
        closers = listOf(
            "he dicho {kao?}",
            "fin de la transmisión divina",
            "esto fue un mensaje del Dios del Random, ignórenlo si quieren",
            "y ahora a dormir {rnd_l}",
            "que {rnd_n} los acompañe",
            "{grito} he dicho",
            "pueden aplaudir ahora",
            "ya, eso, nada más"
        ),
        bits = listOf(
            "{rnd_n}.",
            "¿{rnd_n}? ¿en serio?",
            "ah y {rnd_n} {rnd_a}",
            "plot twist: {rnd_n}",
            "{expr}",
            "{grito}"
        )
    )

    /** Devuelve el paquete de una personalidad concreta (Mezcla Total elige una al azar antes de llamar aquí). */
    fun of(p: Personality): PersonaPack = when (p) {
        Personality.POLITES -> polites
        Personality.NEKO -> neko
        Personality.SENPAI -> senpai
        Personality.GLITCH -> glitch
        Personality.RANDOM_GOD -> randomGod
        Personality.MIX -> polites
    }
}
