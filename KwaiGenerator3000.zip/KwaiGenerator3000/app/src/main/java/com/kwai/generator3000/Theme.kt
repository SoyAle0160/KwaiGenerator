package com.kwai.generator3000

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paleta kawaii: morado, lavanda, rosa y detalles celestes.
val KwaiPurple = Color(0xFF7C4DFF)
val KwaiPurpleDark = Color(0xFF4527A0)
val KwaiLavender = Color(0xFFEDE4FF)
val KwaiLavenderDeep = Color(0xFFCDB8FF)
val KwaiPink = Color(0xFFFF6FC8)
val KwaiPinkSoft = Color(0xFFFFDDF1)
val KwaiSky = Color(0xFF4FC3F7)
val KwaiSkySoft = Color(0xFFD9F3FF)
val KwaiInk = Color(0xFF2A1A52)

private val KwaiColors = lightColorScheme(
    primary = KwaiPurple,
    onPrimary = Color.White,
    secondary = KwaiPink,
    onSecondary = Color.White,
    tertiary = KwaiSky,
    background = KwaiLavender,
    onBackground = KwaiInk,
    surface = Color.White,
    onSurface = KwaiInk
)

@Composable
fun KwaiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = KwaiColors, content = content)
}
