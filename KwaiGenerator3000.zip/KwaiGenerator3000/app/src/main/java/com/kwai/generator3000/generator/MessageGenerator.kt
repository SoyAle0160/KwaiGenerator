package com.kwai.generator3000.generator

import com.kwai.generator3000.Chaos
import com.kwai.generator3000.EmojiAmount
import com.kwai.generator3000.GenSettings
import com.kwai.generator3000.Length
import com.kwai.generator3000.Personality
import com.kwai.generator3000.Topic
import kotlin.random.Random

/** Tipos de "pieza" que forman el cuerpo de un mensaje. */
private enum class Beat { ACTION, REACTION, STATEMENT, SHIFT }

/** Cuánto caos mete cada nivel: pesos de las piezas, interjecciones, gritos y cambios de personalidad. */
private class ChaosConfig(
    val weights: List<Pair<Beat, Float>>,
    val bitChance: Float,
    val screamChance: Float,
    val switchChance: Float
) {
    companion object {
        fun of(chaos: Chaos): ChaosConfig = when (chaos) {
            Chaos.CALM -> ChaosConfig(
                listOf(
                    Beat.ACTION to 0.25f,
                    Beat.REACTION to 0.30f,
                    Beat.STATEMENT to 0.40f,
                    Beat.SHIFT to 0.05f
                ),
                bitChance = 0.05f,
                screamChance = 0f,
                switchChance = 0f
            )
            Chaos.CHAOTIC -> ChaosConfig(
                listOf(
                    Beat.ACTION to 0.22f,
                    Beat.REACTION to 0.25f,
                    Beat.STATEMENT to 0.28f,
                    Beat.SHIFT to 0.25f
                ),
                bitChance = 0.25f,
                screamChance = 0.08f,
                switchChance = 0.06f
            )
            Chaos.UNHINGED -> ChaosConfig(
                listOf(
                    Beat.ACTION to 0.18f,
                    Beat.REACTION to 0.22f,
                    Beat.STATEMENT to 0.20f,
                    Beat.SHIFT to 0.40f
                ),
                bitChance = 0.45f,
                screamChance = 0.35f,
                switchChance = 0.16f
            )
        }
    }
}

/**
 * Rellena los espacios {nombre} de una plantilla con palabras al azar.
 * Funciona sin internet: todo sale de los bancos de WordBank y ThemeBank.
 */
class SlotFiller(
    private val rnd: Random,
    private val topic: Topic,
    private val kaoChance: Float
) {
    private val slotRegex = Regex("\\{(\\w+)(\\?)?\\}")

    fun fill(template: String): String {
        var out = template
        var guard = 0
        // Se repite porque una palabra puede traer otro espacio dentro (p. ej. {n} en una frase de tema).
        while (slotRegex.containsMatchIn(out) && guard < 4) {
            out = slotRegex.replace(out) { m ->
                val name = m.groupValues[1]
                val optional = m.groupValues[2].isNotEmpty()
                val chance = if (name == "kao") kaoChance else 0.5f
                if (optional && rnd.nextFloat() > chance) "" else resolve(name)
            }
            guard += 1
        }
        return slotRegex.replace(out, "")
    }

    private fun resolve(name: String): String = when (name) {
        "kao" -> WordBank.kaomojis.random(rnd)
        "expr" -> WordBank.expressions.random(rnd)
        "grito" -> TextEffects.scream(rnd)
        "tema" -> ThemeBank.noun(topic, rnd)
        "tema_frase" -> ThemeBank.sentence(topic, rnd)
        "rnd_n" -> WordBank.absurdNouns.random(rnd)
        "rnd_a" -> WordBank.absurdActions.random(rnd)
        "rnd_l" -> WordBank.absurdLocations.random(rnd)
        "rnd_p" -> WordBank.absurdPlaces.random(rnd)
        "comida" -> WordBank.foods.random(rnd)
        "animal" -> WordBank.animals.random(rnd)
        "interj" -> WordBank.interjections.random(rnd)
        "jp" -> WordBank.japanese.random(rnd)
        "bin" -> TextEffects.toBinary(WordBank.binaryWords.random(rnd))
        "n" -> rnd.nextInt(2, 100).toString()
        else -> ""
    }
}

/** Generador de mensajes aleatorios 100% local (sin internet ni IA). */
class MessageGenerator(private val rnd: Random = Random.Default) {

    /**
     * Genera un mensaje con los [settings] dados.
     * Evita devolver cualquiera de los textos de [avoid] (el mensaje actual y los últimos del historial).
     */
    fun generate(settings: GenSettings, avoid: Collection<String> = emptyList()): String {
        repeat(MAX_RETRIES) {
            val text = build(settings)
            if (text !in avoid) return text
        }
        return build(settings)
    }

    private fun build(s: GenSettings): String {
        val kaoChance = when (s.emoji) {
            EmojiAmount.FEW -> 0.3f
            EmojiAmount.NORMAL -> 0.55f
            EmojiAmount.MANY -> 0.85f
        }
        val slots = SlotFiller(rnd, s.topic, kaoChance)
        val cfg = ChaosConfig.of(s.chaos)
        val isShort = s.length == Length.SHORT

        val used = mutableSetOf<String>()
        val parts = mutableListOf<String>()
        var persona = if (s.personality == Personality.MIX) randomPersona() else s.personality

        fun add(templates: List<String>) {
            val template = pickUnused(templates, used)
            used.add(template)
            parts.add(slots.fill(template))
        }

        // 1) Comienzo
        if (rnd.nextFloat() < (if (isShort) 0.5f else 0.85f)) {
            add(PersonaPacks.of(persona).openers)
        }

        // 2) Cuerpo: acciones, reacciones, frases del tema y cambios de tema
        val bodyCount = when (s.length) {
            Length.SHORT -> 1
            Length.MEDIUM -> rnd.nextInt(2, 4)
            Length.LONG -> rnd.nextInt(4, 7)
        }
        var mustUseTopic = s.topic != Topic.NONE
        repeat(bodyCount) {
            persona = nextPersona(s.personality, persona, cfg)
            val pack = PersonaPacks.of(persona)
            val beat = if (mustUseTopic) Beat.STATEMENT else pickBeat(cfg)
            mustUseTopic = false
            add(
                when (beat) {
                    Beat.ACTION -> pack.actions
                    Beat.REACTION -> pack.reactions
                    Beat.STATEMENT -> pack.statements
                    Beat.SHIFT -> pack.shifts
                }
            )
            // Interjección caótica suelta
            if (rnd.nextFloat() < cfg.bitChance && !(isShort && parts.size >= 3)) {
                add(pack.bits)
            }
        }

        // 3) Final
        if (rnd.nextFloat() < (if (isShort) 0.45f else 0.8f)) {
            add(PersonaPacks.of(persona).closers)
        }

        // 4) Grito suelto en cualquier posición (solo con caos alto)
        if (rnd.nextFloat() < cfg.screamChance) {
            parts.add(rnd.nextInt(parts.size + 1), TextEffects.scream(rnd))
        }

        // 5) Unir las piezas en una o varias líneas (como mensajes seguidos de WhatsApp)
        val newlineChance = when (s.length) {
            Length.SHORT -> 0f
            Length.MEDIUM -> 0.35f
            Length.LONG -> 0.55f
        }
        val joined = buildString {
            parts.forEachIndexed { i, part ->
                if (i > 0) append(if (rnd.nextFloat() < newlineChance) "\n" else " ")
                append(part)
            }
        }

        // 6) Limpieza, estilo de escritura y emojis
        var text = TextEffects.polish(joined)
        text = TextEffects.applyStyle(text, s.style, s.chaos, rnd)
        return TextEffects.addEmojis(text, s.emoji, EmojiPools.forPersonality(s.personality), rnd)
    }

    /** Elige qué personalidad habla en la siguiente pieza (Mezcla Total cambia casi siempre). */
    private fun nextPersona(mode: Personality, current: Personality, cfg: ChaosConfig): Personality =
        when {
            mode == Personality.MIX -> if (rnd.nextFloat() < 0.7f) randomPersona() else current
            rnd.nextFloat() < cfg.switchChance -> randomPersona()
            else -> mode
        }

    private fun randomPersona(): Personality = CONCRETE.random(rnd)

    private fun pickBeat(cfg: ChaosConfig): Beat {
        val r = rnd.nextFloat()
        var acc = 0f
        for ((beat, weight) in cfg.weights) {
            acc += weight
            if (r < acc) return beat
        }
        return Beat.STATEMENT
    }

    /** Elige una plantilla que todavía no se haya usado en este mensaje. */
    private fun pickUnused(templates: List<String>, used: Set<String>): String {
        val free = templates.filter { it !in used }
        return (if (free.isEmpty()) templates else free).random(rnd)
    }

    private companion object {
        const val MAX_RETRIES = 15
        val CONCRETE = listOf(
            Personality.POLITES,
            Personality.NEKO,
            Personality.SENPAI,
            Personality.GLITCH,
            Personality.RANDOM_GOD
        )
    }
}
