package com.kwai.generator3000.generator

import com.kwai.generator3000.Chaos
import com.kwai.generator3000.EmojiAmount
import com.kwai.generator3000.WritingStyle
import kotlin.random.Random

/** Efectos que se aplican al texto ya armado: estilo de escritura, gritos, emojis y limpieza. */
object TextEffects {

    /** Palabra "limpia": solo letras, con signos opcionales alrededor (¿qué?, nya~, *se). */
    private val wordRegex = Regex("^([^\\p{L}]*)(\\p{L}+)([^\\p{L}]*)$")

    /** Signos de exclamación o pregunta al final de una palabra. */
    private val burstRegex = Regex("[!?](?=\\s|$)")

    /** Formas de escribir rápido en WhatsApp. */
    private val slang = mapOf(
        "que" to "ke", "porque" to "xq", "para" to "pa", "pero" to "pro", "estoy" to "toy",
        "también" to "tmb", "bien" to "bn", "gracias" to "grax", "hola" to "ola", "nada" to "nd",
        "quiero" to "kiero", "casa" to "kasa", "cuando" to "kuando", "esto" to "eto", "ahora" to "ora"
    )

    // ═════════ Utilidades internas ═════════

    /** Aplica [transform] a cada palabra "limpia" y deja intactos kaomojis, emojis y signos. */
    private fun mapWords(text: String, transform: (String) -> String): String =
        text.split("\n").joinToString("\n") { line ->
            line.split(" ").joinToString(" ") { token ->
                val m = wordRegex.matchEntire(token)
                if (m == null) {
                    token
                } else {
                    m.groupValues[1] + transform(m.groupValues[2]) + m.groupValues[3]
                }
            }
        }

    /**
     * Transforma algunas palabras (probabilidad [p]) de al menos [minLen] letras.
     * Garantiza que al menos una palabra cambie, para que el estilo elegido siempre se note.
     */
    private fun mapSome(
        text: String,
        p: Float,
        minLen: Int,
        rnd: Random,
        transform: (String) -> String
    ): String {
        var eligible = 0
        mapWords(text) { w ->
            if (w.length >= minLen) eligible += 1
            w
        }
        val forced = if (eligible > 0) rnd.nextInt(eligible) else -1
        var index = 0
        return mapWords(text) { w ->
            if (w.length < minLen) {
                w
            } else {
                val i = index
                index += 1
                if (i == forced || rnd.nextFloat() < p) transform(w) else w
            }
        }
    }

    private fun scaled(chaos: Chaos, calm: Float, chaotic: Float, unhinged: Float): Float =
        when (chaos) {
            Chaos.CALM -> calm
            Chaos.CHAOTIC -> chaotic
            Chaos.UNHINGED -> unhinged
        }

    /** Tartamudeo: "senpai" -> "s-senpai" (a veces "s-s-senpai"). */
    private fun stutterWord(w: String, rnd: Random): String {
        val first = w.first()
        return if (rnd.nextFloat() < 0.2f) "$first-$first-$w" else "$first-$w"
    }

    private fun matchCase(original: String, replacement: String): String =
        if (original.first().isUpperCase()) {
            replacement.replaceFirstChar { it.uppercase() }
        } else {
            replacement
        }

    /** Error de tecleo intencional: letra repetida, letras cambiadas, letra perdida o slang. */
    private fun typoWord(w: String, rnd: Random): String {
        val short = slang[w.lowercase()]
        if (short != null && rnd.nextFloat() < 0.75f) return matchCase(w, short)
        if (w.length < 3) return w
        return when (rnd.nextInt(5)) {
            0 -> {
                val i = rnd.nextInt(1, w.length)
                w.substring(0, i) + w[i] + w.substring(i)
            }
            1 -> {
                val i = rnd.nextInt(0, w.length - 1)
                val sb = StringBuilder(w)
                sb.setCharAt(i, w[i + 1])
                sb.setCharAt(i + 1, w[i])
                sb.toString()
            }
            2 -> {
                val i = rnd.nextInt(1, w.length)
                w.removeRange(i, i + 1)
            }
            3 -> {
                val swapped = w.replace("qu", "k").replace("Qu", "K")
                if (swapped != w) swapped else w + w.last()
            }
            else -> w + w.last().toString().repeat(rnd.nextInt(1, 4))
        }
    }

    // ═════════ Estilo de escritura ═════════

    /** Aplica el sabor del nivel de caos y después el estilo de escritura elegido. */
    fun applyStyle(text: String, style: WritingStyle, chaos: Chaos, rnd: Random): String {
        val flavored = chaosFlavor(text, chaos, rnd)
        return when (style) {
            WritingStyle.NORMAL -> flavored
            WritingStyle.CAPS -> flavored.uppercase()
            WritingStyle.STUTTER ->
                mapSome(flavored, scaled(chaos, 0.22f, 0.32f, 0.45f), 3, rnd) { stutterWord(it, rnd) }
            WritingStyle.TYPOS ->
                mapSome(flavored, scaled(chaos, 0.15f, 0.25f, 0.40f), 2, rnd) { typoWord(it, rnd) }
            WritingStyle.MIX -> mixStyle(flavored, chaos, rnd)
        }
    }

    /** Mezcla: cada palabra puede salir en MAYÚSCULAS, tartamudeada o con error. */
    private fun mixStyle(text: String, chaos: Chaos, rnd: Random): String {
        val scale = scaled(chaos, 0.6f, 1f, 1.5f)
        return mapWords(text) { w ->
            val r = rnd.nextFloat()
            when {
                w.length >= 3 && r < 0.12f * scale -> w.uppercase()
                w.length >= 3 && r < 0.24f * scale -> stutterWord(w, rnd)
                w.length >= 2 && r < 0.36f * scale -> typoWord(w, rnd)
                else -> w
            }
        }
    }

    /** Alarga vocales (holaaaa), grita palabras sueltas y repite !!! según el caos. Tranquilo no cambia nada. */
    private fun chaosFlavor(text: String, chaos: Chaos, rnd: Random): String {
        val stretchP = scaled(chaos, 0f, 0.06f, 0.14f)
        val shoutP = scaled(chaos, 0f, 0.04f, 0.12f)
        val burstP = scaled(chaos, 0f, 0.25f, 0.6f)
        if (chaos == Chaos.CALM) return text

        val words = mapWords(text) { w ->
            when {
                w.length >= 3 && rnd.nextFloat() < stretchP && w.last().lowercaseChar() in "aeiou" ->
                    w + w.last().toString().repeat(rnd.nextInt(2, 6))
                w.length >= 3 && rnd.nextFloat() < shoutP -> w.uppercase()
                else -> w
            }
        }
        return burstRegex.replace(words) { m ->
            if (rnd.nextFloat() < burstP) m.value.repeat(rnd.nextInt(2, 5)) else m.value
        }
    }

    // ═════════ Gritos y binario ═════════

    /** Grito único cada vez: KYAAAAA!!, NOOOOOO!, ARRRRRR!!! ... */
    fun scream(rnd: Random): String {
        val base = listOf("A", "KYA", "NO", "WA", "EEK", "ARR", "NYA", "UWA", "OI").random(rnd)
        val stretch = base.last().toString().repeat(rnd.nextInt(3, 10))
        val bang = "!".repeat(rnd.nextInt(1, 4))
        return base + stretch + bang
    }

    /** "hola" -> "01101000 01101111 01101100 01100001". */
    fun toBinary(word: String): String =
        word.map { it.code.toString(2).padStart(8, '0') }.joinToString(" ")

    // ═════════ Emojis y limpieza final ═════════

    /** Reparte emojis dentro del texto y agrega un racimo al final según la cantidad elegida. */
    fun addEmojis(text: String, amount: EmojiAmount, pool: List<String>, rnd: Random): String {
        val inlineCount = when (amount) {
            EmojiAmount.FEW -> 0
            EmojiAmount.NORMAL -> rnd.nextInt(1, 3)
            EmojiAmount.MANY -> rnd.nextInt(3, 7)
        }
        val tailCount = when (amount) {
            EmojiAmount.FEW -> if (rnd.nextFloat() < 0.6f) 1 else 0
            EmojiAmount.NORMAL -> rnd.nextInt(1, 3)
            EmojiAmount.MANY -> rnd.nextInt(3, 6)
        }

        val lines = text.split("\n").map { it.split(" ").toMutableList() }
        val spots = lines.indices
            .flatMap { li -> lines[li].indices.map { ti -> li to ti } }
            .shuffled(rnd)
        spots.take(inlineCount).forEach { (li, ti) ->
            lines[li][ti] = lines[li][ti] + " " + pool.random(rnd)
        }

        val body = lines.joinToString("\n") { it.joinToString(" ") }
        val tail = (1..tailCount).joinToString("") { pool.random(rnd) }
        return if (tail.isEmpty()) body else "$body $tail"
    }

    /** Quita espacios dobles y pone mayúscula inicial en cada línea. */
    fun polish(text: String): String =
        text.split("\n")
            .joinToString("\n") { capitalizeFirst(it.trim()) }
            .replace(Regex(" {2,}"), " ")
            .replace(" ,", ",")
            .trim()

    /** Pone en mayúscula la primera letra si está al principio de la línea (después de ¿ ¡ o *). */
    private fun capitalizeFirst(line: String): String {
        val idx = line.indexOfFirst { it.isLetter() }
        return if (idx in 0..1) {
            line.substring(0, idx) + line[idx].uppercaseChar() + line.substring(idx + 1)
        } else {
            line
        }
    }
}
