# Kwai Generator 3000 🎲💜

App Android (Kotlin + Jetpack Compose) que genera mensajes aleatorios estilo anime / kawaii / caótico,
inspirados en chats de grupos de WhatsApp.

- 100 % sin internet: todo sale de plantillas y bancos de palabras guardados en la app.
- Sin cuentas, sin suscripciones, sin servidores, sin APIs de IA.
- Sin permisos: el `AndroidManifest.xml` no pide ninguno.
- Favoritos, historial y ajustes se guardan solo en el teléfono.

> **Estado de verificación (sin adornos).** El código se revisó de forma estática (llaves, imports,
> referencias entre archivos, recursos XML) y el generador se simuló en Python con las mismas
> plantillas. **No se pudo compilar** donde se creó (ese entorno no tiene Android SDK, Gradle ni internet),
> así que nadie ha confirmado todavía que compile. Si el primer build muestra un error, copia el
> mensaje completo y se corrige.

## Estructura del proyecto

```
KwaiGenerator3000/
├── .github/workflows/build-apk.yml      ← compila el APK en la nube de GitHub
├── .gitignore
├── README.md
├── settings.gradle.kts                  ← repositorios y módulos
├── build.gradle.kts                     ← versiones de los plugins
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts                 ← dependencias (solo Compose y AndroidX)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml          ← sin permisos
        ├── java/com/kwai/generator3000/
        │   ├── MainActivity.kt          ← arranca la interfaz
        │   ├── KwaiApp.kt               ← pantallas, botones y animaciones
        │   ├── MainViewModel.kt         ← une generador + almacenamiento + interfaz
        │   ├── Storage.kt               ← favoritos, historial y ajustes (local)
        │   ├── Models.kt                ← personalidades, ajustes y mensajes guardados
        │   ├── Theme.kt                 ← colores morado, lavanda, rosa y celeste
        │   └── generator/
        │       ├── MessageGenerator.kt  ← arma el mensaje (comienzo + piezas + final)
        │       ├── PersonaPacks.kt      ← plantillas de las 5 personalidades
        │       ├── WordBank.kt          ← palabras, temas, kaomojis y emojis
        │       └── TextEffects.kt       ← mayúsculas, tartamudeo, errores, gritos, emojis
        └── res/                         ← icono de gatito, textos y tema
```

## Cómo obtener el APK (elige una opción)

Un APK solo se puede crear con las herramientas de Android (JDK 17 + Android SDK + Gradle).
Internet hace falta **solo para compilar**; la app ya instalada funciona sin conexión.

### Opción A: en la nube con GitHub (no instalas nada)

1. Crea una cuenta gratis en github.com y un repositorio nuevo (por ejemplo `kwai-generator-3000`).
2. Descomprime el ZIP. En el repositorio pulsa **Add file → Upload files** y arrastra **el contenido**
   de la carpeta `KwaiGenerator3000` (no la carpeta en sí). Incluye la carpeta oculta `.github`
   (en Mac se ven las carpetas ocultas con `Cmd + Shift + .`). Pulsa **Commit changes**.
3. Abre la pestaña **Actions**, elige **Compilar APK** y pulsa **Run workflow**.
   (Si ya arrancó sola al subir los archivos, espera a que termine: tarda unos 5 a 10 minutos.)
4. Entra a la ejecución terminada. Abajo, en **Artifacts**, descarga **KwaiGenerator3000-APK**.
   Es un `.zip` que contiene `app-debug.apk`.

Si no aparece el flujo de trabajo, crea el archivo a mano: **Add file → Create new file**, nómbralo
`.github/workflows/build-apk.yml` y pega ahí el contenido del mismo archivo del ZIP.

### Opción B: con Android Studio

1. Instala Android Studio (gratis) desde developer.android.com/studio.
2. **Open** → elige la carpeta `KwaiGenerator3000`. Si pregunta, confía en el proyecto.
3. Espera a que termine **Gradle Sync** (la primera vez descarga varios GB; necesita internet).
4. Menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Cuando termine, pulsa **locate** en el aviso. El archivo es
   `app/build/outputs/apk/debug/app-debug.apk`.

Si Android Studio ofrece actualizar Gradle o el plugin de Android, puedes decir que no;
las versiones del proyecto ya están fijadas (Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21).

### Opción C: línea de comandos

Con JDK 17, Android SDK (plataforma 35) y Gradle 8.9 instalados: `gradle assembleDebug`.

## Instalar en el Samsung Galaxy A16

1. Pasa `app-debug.apk` al celular (descargándolo directo, por cable USB o por Drive).
2. Ábrelo desde **Mis archivos**. Si Android lo pide, activa **Permitir desde esta fuente**
   para la app que usaste (Mis archivos o Chrome).
3. Pulsa **Instalar**. Si Play Protect avisa que no conoce la app, elige **Instalar de todos modos**
   (es una app tuya y no pide permisos).

## Cómo se usa

1. Arriba elige una **personalidad** (desliza para ver las 6).
2. Abre **⚙️ Ajustes del caos** para cambiar nivel de caos, longitud, cantidad de emojis, tema y estilo de escritura.
3. Pulsa **🎲 GENERAR CAOS** (o **💥 GENERAR OTRO**). El mensaje aparece en la tarjeta central.
4. Con los botones de abajo: **📋 copiar**, **☆ favorito** y **📤 compartir** (abre el menú de Android, por ejemplo WhatsApp).
5. En la barra inferior: **⭐ Favoritos** y **🕘 Historial** (últimos 50 mensajes, se guardan en el teléfono).

## Cómo funciona por dentro

- Un mensaje = un **comienzo** + de 1 a 6 **piezas** (acción, reacción, frase del tema, cambio de tema o
  interjección) + un **final**. Cada personalidad tiene sus propias plantillas.
- Las plantillas tienen espacios como `{kao}`, `{tema}`, `{grito}` o `{rnd_n}` que se rellenan con
  palabras al azar de `WordBank.kt`. Un espacio con `?` (por ejemplo `{kao?}`) aparece solo a veces.
- El **nivel de caos** cambia las probabilidades: más gritos, más cambios de personalidad a mitad
  de mensaje, letras alargadas y signos repetidos.
- El **estilo de escritura** (MAYÚSCULAS, tartamudeo, errores, mezcla) y los **emojis** se aplican al final.
- No repite: compara con el mensaje actual y con los últimos 12 del historial.
- Contenido limpio: sin groserías.
- Para agregar frases propias, edita las listas de `PersonaPacks.kt` (plantillas) o `WordBank.kt` (palabras).

## Problemas comunes

- **SDK location not found**: en Android Studio abre **Tools → SDK Manager** e instala Android 15 (API 35).
- **Unsupported class file major version / Java**: en **Settings → Build Tools → Gradle**, pon
  *Gradle JDK* en el JDK 17 o en el JDK incluido con Android Studio.
- **Falla un paso en GitHub Actions**: abre el paso en rojo y copia las últimas líneas del error.
- **No se instala el APK**: revisa que tengas activado el permiso de instalar desde esa fuente.
